package com.gmail.kozmazbalazs;

public abstract class Cell {

	protected Position position;

	public Cell(Position position) {

		this.position = position;
	}

	abstract int getValue();
}
