package com.gmail.kozmazbalazs;

public class FormulaCell extends Cell {

    private Operator operator;
	private Cell firstCell;
	private Cell secondCell;
	private double value;

	public FormulaCell(Position position, Cell firstCell, Operator operator, Cell secondCell) {
		super(position);

		this.firstCell=firstCell;
		this.secondCell=secondCell;
        this.operator = operator;
		value = operator.calculate(firstCell.getValue(), secondCell.getValue());
	}

	public void setNewFormula(Cell firstCell, Operator operator, Cell secondCell){
        if(firstCell.position.equals(this.position) || secondCell.position.equals(this.position)){
            System.out.println("Error, circular reference!");
        } else {
            this.firstCell = firstCell;
            this.secondCell = secondCell;
            this.operator = operator;
            update();
        }
    }

	public int getValue() {

		return (int) value;
	}

	public void update(){
        value = operator.calculate(firstCell.getValue(), secondCell.getValue());
    }

	@Override
	public String toString() {

		return "FormulaCell = " + value;
	}

}
