package com.gmail.kozmazbalazs;

import java.util.*;

public class Main {

	public static void main(String[] args) {

		Random random = new Random();
		Spreadsheet sp = new Spreadsheet();
        LinkedHashMap<Position,Cell> cells = sp.getCells();

		Position p1 = new Position(0,0);
		Position p2 = new Position(0,1);
		Position p3 = new Position(0,2);
        Position p4 = new Position(0,3);
        Position p5 = new Position(1,0);
        Position p6 = new Position(1,1);
        Position p7 = new Position(1,2);
        Position p8 = new Position(1,3);
        Position p9 = new Position(2,0);
        Position p10 = new Position(2,1);
        Position p11 = new Position(2,2);
        Position p12 = new Position(2,3);

        cells.put(p1, new ValueCell(p1, random.nextInt(10)));
        cells.put(p2, new ValueCell(p2, random.nextInt(10)));
        cells.put(p3, new ValueCell(p3, random.nextInt(10)));
        cells.put(p4, new ValueCell(p4, random.nextInt(10)));
        cells.put(p5, new ValueCell(p5, random.nextInt(10)));
        cells.put(p6, new ValueCell(p6, random.nextInt(10)));
        cells.put(p7, new ValueCell(p7, random.nextInt(10)));
        cells.put(p8, new ValueCell(p8, random.nextInt(10)));

        cells.put(p9, new FormulaCell(p9, cells.get(p1), Operator.ADD, cells.get(p2)));
        cells.put(p10, new FormulaCell(p10, cells.get(p3), Operator.SUBTRACT, cells.get(p4)));
        cells.put(p11, new FormulaCell(p11, cells.get(p5), Operator.MULTIPLY, cells.get(p6)));
        cells.put(p12, new FormulaCell(p12, cells.get(p7), Operator.DIVIDE, cells.get(p8)));

        sp.showSpreadsheet();

        ((ValueCell)cells.get(p1)).addObserver(cells.get(p9));
        ((ValueCell)cells.get(p1)).setValue(6);

        sp.showSpreadsheet();

        ((FormulaCell)cells.get(p12)).setNewFormula(cells.get(p1), Operator.MULTIPLY, cells.get(p2));

        sp.showSpreadsheet();

        ((FormulaCell)cells.get(p12)).setNewFormula(cells.get(p12), Operator.MULTIPLY, cells.get(p2));

	}
}
