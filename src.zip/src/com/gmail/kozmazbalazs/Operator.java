package com.gmail.kozmazbalazs;

public enum Operator {
	ADD {
		public double calculate(int a, int b) {
			return a + b;
		}
	},
	SUBTRACT {
		public double calculate(int a, int b) {
			return a - b;
		}
	},
	MULTIPLY {
		public double calculate(int a, int b) {
			return a * b;
		}
	},
	DIVIDE {
		public double calculate(int a, int b) {
			if (b == 0)
				return 0;
			else
				return a / b;
		}
	};

	public abstract double calculate(int a, int b);
}
