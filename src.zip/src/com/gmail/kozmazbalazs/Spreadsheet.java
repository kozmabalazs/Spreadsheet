package com.gmail.kozmazbalazs;

import java.util.LinkedHashMap;

public class Spreadsheet {

	private LinkedHashMap<Position, Cell> cells;

	public Spreadsheet() {
		cells = new LinkedHashMap<Position, Cell>();
	}

	public LinkedHashMap<Position, Cell> getCells() {
		return cells;
	}

	public void showSpreadsheet() {
		for (Cell cell : cells.values()) {
			System.out.println(cell.toString());
		}
	}
}
