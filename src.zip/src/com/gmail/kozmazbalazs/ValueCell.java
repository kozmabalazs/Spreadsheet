package com.gmail.kozmazbalazs;

import java.util.ArrayList;
import java.util.List;

public class ValueCell extends Cell {

	private int value;
	List<Cell> listofObservers;

	public ValueCell(Position position, int value) {
		super(position);
		this.value = value;
		listofObservers = new ArrayList<Cell>();
	}

	public int getValue() {

		return value;
	}

	public void setValue(int value) {

		this.value = value;
		notifyObservers();
	}

	public void addObserver(Cell cell){
		listofObservers.add(cell);
	}

	public void notifyObservers(){
		for(Cell cell: listofObservers){
			if(cell instanceof FormulaCell)
				((FormulaCell)cell).update();
		}
	}

	@Override
	public String toString() {

		return "ValueCell = " + value;
	}

}
